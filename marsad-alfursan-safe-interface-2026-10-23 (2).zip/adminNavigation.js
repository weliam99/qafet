let openedFromAdmin = false;

export function markOpenedFromAdmin() {
  openedFromAdmin = true;
}

export function clearOpenedFromAdmin() {
  openedFromAdmin = false;
}

export function renderAdminReturn({ activeView, t, renderView }) {
  if (!openedFromAdmin || activeView === 'overview') return;
  const view = document.querySelector(`#view-${activeView}`);
  if (!view) return;

  view.querySelector('.admin-back-row')?.remove();
  const row = document.createElement('div');
  row.className = 'admin-back-row';
  const button = document.createElement('button');
  button.className = 'btn btn-outline admin-back';
  button.type = 'button';
  button.textContent = `→ ${t('adminCenter.back')}`;
  button.addEventListener('click', () => {
    clearOpenedFromAdmin();
    renderView('overview');
    requestAnimationFrame(() => {
      const center = document.querySelector('.admin-control-center');
      center?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      center?.querySelector('[data-admin-go]')?.focus({ preventScroll: true });
    });
  });
  row.appendChild(button);
  view.prepend(row);
}
