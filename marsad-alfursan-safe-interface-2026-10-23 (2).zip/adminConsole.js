import {isAdminRole} from './roleAccess.js';
import {markOpenedFromAdmin} from './adminNavigation.js';

const list=value=>Array.isArray(value)?value:[];
const esc=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[char]));

export function adminControlCenterMarkup({state,t,esc}){
  const account=state.users?.find(user=>user.id===state.currentUser?.id)||state.currentUser||{};
  if(!isAdminRole(account.role))return '';
  const users=list(state.users).filter(user=>!isAdminRole(user.role));
  const online=users.filter(user=>['present','late'].includes(user.status)).length;
  const openReports=list(state.reports).filter(report=>report.status!=='closed').length;
  const openWarnings=list(state.warnings).filter(warning=>warning.status==='pending').length;
  const history=list(state.broadcasts).slice(0,4);
  const action=(view,label,icon)=>`<button class="btn btn-outline admin-action" type="button" data-admin-go="${view}">${icon} ${label} ←</button>`;
  return `<section class="admin-control-center" aria-label="${esc(t('adminCenter.title'))}">
    <div class="card admin-center-head"><div><span class="section-kicker">${esc(t('adminCenter.kicker'))}</span><h2>${esc(t('adminCenter.title'))}</h2><p>${esc(t('adminCenter.subtitle'))}</p></div><span class="admin-center-badge">${esc(t('auth.admin'))}</span></div>
    <div class="admin-module-grid">
      <button class="admin-module-card" type="button" data-admin-go="map"><span class="admin-module-icon">⌖</span><strong>${esc(t('adminCenter.siteRanges'))}</strong><small>${list(state.sites).length} ${esc(t('sections.count'))}</small></button>
      <button class="admin-module-card" type="button" data-admin-go="map"><span class="admin-module-icon">◉</span><strong>${esc(t('adminCenter.tracking'))}</strong><small>${online} ${esc(t('adminCenter.activePeople'))}</small></button>
      <button class="admin-module-card" type="button" data-admin-go="settings"><span class="admin-module-icon">✦</span><strong>${esc(t('adminCenter.patrolRoutes'))}</strong><small>${list(state.patrolRoutes).length} ${esc(t('adminCenter.routes'))}</small></button>
      <button class="admin-module-card" type="button" data-admin-go="reports"><span class="admin-module-icon">!</span><strong>${esc(t('nav.reports'))}</strong><small>${openReports} ${esc(t('reports.open'))}</small></button>
      <button class="admin-module-card" type="button" data-admin-go="requests"><span class="admin-module-icon">⚠</span><strong>${esc(t('adminCenter.alerts'))}</strong><small>${openWarnings} ${esc(t('warnings.pending'))}</small></button>
      <button class="admin-module-card" type="button" data-admin-go="requests"><span class="admin-module-icon">✉</span><strong>${esc(t('adminCenter.broadcast'))}</strong><small>${list(state.broadcasts).length} ${esc(t('adminCenter.messagesSent'))}</small></button>
      <button class="admin-module-card" type="button" data-admin-go="requests"><span class="admin-module-icon">◎</span><strong>${esc(t('opinions.title'))}</strong><small>${list(state.opinions).length} ${esc(t('adminCenter.opinionsCount'))}</small></button>
      <button class="admin-module-card" type="button" data-admin-go="patrols"><span class="admin-module-icon">★</span><strong>${esc(t('patrol.leaderboard'))}</strong><small>${esc(t('patrol.roundLeaderboard'))}</small></button>
    </div>
    <div class="admin-center-columns">
      <div class="card admin-broadcast-card"><div class="card-head"><div><h3>${esc(t('adminCenter.broadcastTitle'))}</h3><small>${esc(t('adminCenter.broadcastHint'))}</small></div><span class="pill dark">${users.length} ${esc(t('adminCenter.recipients'))}</span></div><form id="broadcastForm"><label class="sr-only" for="broadcastText">${esc(t('adminCenter.broadcastPlaceholder'))}</label><textarea id="broadcastText" rows="3" placeholder="${esc(t('adminCenter.broadcastPlaceholder'))}" required></textarea><div class="header-actions"><button class="btn btn-primary" type="submit">${esc(t('adminCenter.sendBroadcast'))}</button>${action('requests',t('adminCenter.openInbox'),'↗')}</div></form></div>
      <div class="card admin-quick-card"><div class="card-head"><div><h3>${esc(t('adminCenter.quickTitle'))}</h3><small>${esc(t('adminCenter.quickHint'))}</small></div></div><div class="admin-quick-actions">${action('patrols',t('nav.patrols'),'✦')}${action('map',t('adminCenter.siteRanges'),'⌖')}${action('reports',t('nav.reports'),'!')}${action('settings',t('adminCenter.manageSections'),'⚙')}</div></div>
    </div>
    <div class="card admin-broadcast-history"><div class="card-head"><div><h3>${esc(t('adminCenter.historyTitle'))}</h3><small>${esc(t('adminCenter.historyHint'))}</small></div></div>${history.length?`<div class="admin-history-list">${history.map(item=>`<div class="admin-history-row"><span class="admin-history-dot"></span><div><strong>${esc(item.text)}</strong><small>${esc(item.sender||t('auth.admin'))} · ${esc(item.time||t('common.now'))}</small></div><b>${Number(item.recipients||0)}</b></div>`).join('')}</div>`:`<div class="empty-state">${esc(t('adminCenter.noHistory'))}</div>`}</div>
  </section>`;
}

export function bindAdminControlCenter({state,t,saveState,showToast,renderView}){
  document.querySelectorAll('[data-admin-go]').forEach(button=>button.addEventListener('click',()=>{markOpenedFromAdmin();renderView(button.dataset.adminGo)}));
  const form=document.querySelector('#broadcastForm');
  form?.addEventListener('submit',event=>{
    event.preventDefault();
    const text=String(document.querySelector('#broadcastText')?.value||'').trim();
    if(!text){showToast(t('common.required'));return;}
    const account=state.users?.find(user=>user.id===state.currentUser?.id)||state.currentUser||{};
    const recipients=list(state.users).filter(user=>user.id!==account.id);
    state.notifications=list(state.notifications);
    recipients.forEach(user=>state.notifications.unshift({id:`broadcast-${Date.now()}-${user.id}`,type:'broadcast',targetUserId:user.id,text,time:t('common.now'),read:false}));
    state.broadcasts=list(state.broadcasts);
    state.broadcasts.unshift({id:`BC-${Date.now()}`,text,sender:account.name||t('auth.admin'),senderId:account.id,time:t('common.now'),recipients:recipients.length});
    state.broadcasts=state.broadcasts.slice(0,50);state.notifications=state.notifications.slice(0,120);saveState();showToast(t('adminCenter.broadcastSent'));form.reset();
    const root=document.querySelector('#view-overview');if(root){root.querySelector('.admin-control-center')?.remove();root.insertAdjacentHTML('beforeend',adminControlCenterMarkup({state,t,esc}));bindAdminControlCenter({state,t,saveState,showToast,renderView});}
  });
}
